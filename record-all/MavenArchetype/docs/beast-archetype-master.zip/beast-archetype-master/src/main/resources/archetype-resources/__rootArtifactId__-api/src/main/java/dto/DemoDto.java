package ${package}.dto;

public class DemoDto {

}
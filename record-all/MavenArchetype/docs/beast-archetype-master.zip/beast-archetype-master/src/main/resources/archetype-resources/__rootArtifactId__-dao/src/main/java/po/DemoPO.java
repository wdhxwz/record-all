package ${package}.po;

public class DemoPO {

}
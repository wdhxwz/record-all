package ${package}.enums;

public enum DemoEnum {

}
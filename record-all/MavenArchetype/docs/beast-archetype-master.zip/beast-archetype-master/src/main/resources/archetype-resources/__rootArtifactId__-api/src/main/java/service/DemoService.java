package ${package}.service;

public interface DemoService {

}
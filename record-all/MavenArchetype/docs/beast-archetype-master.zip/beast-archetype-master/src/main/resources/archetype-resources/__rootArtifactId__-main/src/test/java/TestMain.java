package ${groupId}.${artifactId}.test;

import org.junit.Test;

/**
 * <p>Title: thebeastshop</p>
 * <p>Copyright: Copyright (c) 2016</p>
 * @author hafiz.zhang
 * @date 2017-1-10
 * @description 
 */
public class TestMain {
	@Test
	public void test() {
		// DemoService service = ServiceUtils.getService(DemoService.class);
	}
}

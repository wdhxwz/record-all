package ${package}.mapper;

public class DemoMapper {

}
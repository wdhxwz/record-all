package ${package}.service.impl;

public class DemoServiceImpl {

}
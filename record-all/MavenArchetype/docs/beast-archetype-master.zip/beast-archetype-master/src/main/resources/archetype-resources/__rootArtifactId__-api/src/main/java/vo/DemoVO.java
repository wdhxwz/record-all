package ${package}.vo;

public class DemoVO {
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}